package my.Laba1;

public class RecIntegral {

    private double lowerLimit;
    private double upperLimit;
    private double range;
    private double result;

    public RecIntegral(double lowerLimit, double upperLimit, double range) throws InvalidRangeException {

        if (!isValid(lowerLimit) || !isValid(upperLimit) || !isValid(range)) {
            throw new InvalidRangeException("Значения должны быть в диапазоне 0.000001 – 1000000");
        }

        if (range <= 0) {
            throw new InvalidRangeException("Шаг должен быть больше 0");
        }

        if (upperLimit <= lowerLimit) {
            throw new InvalidRangeException("Верхний предел должен быть больше нижнего");
        }

        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
        this.range = range;
        this.result = 0;
    }

    private boolean isValid(double x) {
        return x >= 0.000001 && x <= 1000000;
    }

    public double getLowerLimit() { return lowerLimit; }
    public double getUpperLimit() { return upperLimit; }
    public double getRange() { return range; }
    public double getResult() { return result; }

    public void setResult(double result) {
        this.result = result;
    }
}