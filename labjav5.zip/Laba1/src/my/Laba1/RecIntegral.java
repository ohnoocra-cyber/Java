package my.Laba1;

import java.io.Serializable;

public class RecIntegral implements Serializable {

    private static final long serialVersionUID = 1L;

    private double lowerLimit;
    private double upperLimit;
    private double range;
    private double result;

    public RecIntegral(double lowerLimit, double upperLimit, double range)
            throws InvalidRangeException {

        if (lowerLimit < 0.000001 || lowerLimit > 1000000 ||
            upperLimit < 0.000001 || upperLimit > 1000000 ||
            range < 0.000001 || range > 1000000) {

            throw new InvalidRangeException("Значения должны быть в диапазоне 0.000001 - 1000000");
        }

        if (upperLimit <= lowerLimit) {
            throw new InvalidRangeException("Верхняя граница должна быть больше нижней");
        }

        if (range <= 0) {
            throw new InvalidRangeException("Шаг должен быть > 0");
        }

        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
        this.range = range;
        this.result = 0;
    }

    public double getLowerLimit() { return lowerLimit; }
    public double getUpperLimit() { return upperLimit; }
    public double getRange() { return range; }
    public double getResult() { return result; }

    public void setResult(double result) {
        this.result = result;
    }
}