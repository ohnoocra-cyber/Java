
package my.Laba1;

import java.util.ArrayList;
import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;



 
public class Laba1UI extends javax.swing.JFrame {
ArrayList<RecIntegral> arrInteg = new ArrayList<>();

  
    public Laba1UI() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldLowLim = new javax.swing.JTextField();
        jTextFieldUpperLim = new javax.swing.JTextField();
        jTextFieldStep = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        Calculate = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        Fill = new javax.swing.JButton();
        SaveTXT = new javax.swing.JButton();
        LoadTXT = new javax.swing.JButton();
        SaveBIN = new javax.swing.JButton();
        LoadBIN = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "e ^ -X"));
        jPanel3.setToolTipText("e ^ -X");
        jPanel3.setName("cos X"); // NOI18N
        jPanel3.setNextFocusableComponent(this);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("нп");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("вп");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("шаг");

        jTextFieldLowLim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldLowLimActionPerformed(evt);
            }
        });

        jTextFieldUpperLim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldUpperLimActionPerformed(evt);
            }
        });

        Add.setText("добавить");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });

        Delete.setText("удалить");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        Calculate.setText("рассчитать");
        Calculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateActionPerformed(evt);
            }
        });

        Clear.setText("очистить");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        Fill.setText("заполнить");
        Fill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FillActionPerformed(evt);
            }
        });

        SaveTXT.setBackground(new java.awt.Color(204, 204, 204));
        SaveTXT.setText("Save TXT");
        SaveTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveTXTActionPerformed(evt);
            }
        });

        LoadTXT.setBackground(new java.awt.Color(204, 204, 204));
        LoadTXT.setText("Load TXT");
        LoadTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoadTXTActionPerformed(evt);
            }
        });

        SaveBIN.setBackground(new java.awt.Color(204, 204, 204));
        SaveBIN.setText("Save BIN");
        SaveBIN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBINActionPerformed(evt);
            }
        });

        LoadBIN.setBackground(new java.awt.Color(204, 204, 204));
        LoadBIN.setText("Load BIN");
        LoadBIN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoadBINActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel2)
                        .addComponent(jLabel1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel3)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jTextFieldUpperLim, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextFieldLowLim, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTextFieldStep, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Add, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Fill, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(Calculate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(SaveTXT)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(LoadBIN)
                                .addGap(8, 8, 8))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(SaveBIN)
                                .addContainerGap())))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(LoadTXT)
                        .addGap(10, 10, 10))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldLowLim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Add)
                    .addComponent(jLabel1)
                    .addComponent(Clear)
                    .addComponent(SaveTXT))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldUpperLim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete)
                    .addComponent(jLabel2)
                    .addComponent(Fill)
                    .addComponent(LoadTXT))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldStep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Calculate)
                    .addComponent(jLabel3)
                    .addComponent(SaveBIN))
                .addGap(18, 18, 18)
                .addComponent(LoadBIN)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTable1.setForeground(new java.awt.Color(255, 0, 51));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "нп", "вп", "шаг", "рез"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE))
                .addContainerGap(7, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        // TODO add your handling code here:
      
     try {

        double lowLim = Double.parseDouble(jTextFieldLowLim.getText().trim());
        double upperLim = Double.parseDouble(jTextFieldUpperLim.getText().trim());
        double step = Double.parseDouble(jTextFieldStep.getText().trim());

        RecIntegral rec = new RecIntegral(lowLim, upperLim, step);

        arrInteg.add(rec);

        DefaultTableModel tModel = (DefaultTableModel) jTable1.getModel();
        tModel.addRow(new Object[]{lowLim, upperLim, step, ""});

        jTextFieldLowLim.setText("");
        jTextFieldUpperLim.setText("");
        jTextFieldStep.setText("");

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Введите корректные числа");

    } catch (InvalidRangeException ex) {
        JOptionPane.showMessageDialog(null, ex.getMessage());
    }
    }//GEN-LAST:event_AddActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
           DefaultTableModel tModel = (DefaultTableModel) jTable1.getModel();

    int rowNum = jTable1.getSelectedRow();

    if (rowNum == -1) {

        JOptionPane.showMessageDialog(null, "Выберите строку");

    } else {

        tModel.removeRow(rowNum);
        arrInteg.remove(rowNum);
    }
    }//GEN-LAST:event_DeleteActionPerformed

    private void CalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalculateActionPerformed
          DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

    int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(null, "Выберите строку");
        return;
    }

    RecIntegral rec = arrInteg.get(row);

    double lower = rec.getLowerLimit();
    double upper = rec.getUpperLimit();
    double step = rec.getRange();

    int THREADS = 5;

    IntegralThread[] threads = new IntegralThread[THREADS];

    double range = (upper - lower) / THREADS;

    double start = lower;

    
    for (int i = 0; i < THREADS; i++) {

        double end = (i == THREADS - 1) ? upper : start + range;

        threads[i] = new IntegralThread(start, end, step);
        threads[i].start();

        start = end;
    }

    
    double total = 0;

    for (int i = 0; i < THREADS; i++) {
        try {
            threads[i].join();
            total += threads[i].getResult();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    rec.setResult(total);
    model.setValueAt(total, row, 3);
    }//GEN-LAST:event_CalculateActionPerformed



    private void jTextFieldLowLimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldLowLimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldLowLimActionPerformed

    private void jTextFieldUpperLimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldUpperLimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldUpperLimActionPerformed

    private void FillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FillActionPerformed
    DefaultTableModel tModel = (DefaultTableModel) jTable1.getModel();

    tModel.setRowCount(0);

    for (RecIntegral rec : arrInteg) {
        tModel.addRow(new Object[]{
            rec.getLowerLimit(),
            rec.getUpperLimit(),
            rec.getRange(),
            rec.getResult()
        });
    }
    }//GEN-LAST:event_FillActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
       DefaultTableModel tModel = (DefaultTableModel) jTable1.getModel();
    tModel.setRowCount(0); 
    }//GEN-LAST:event_ClearActionPerformed

    private void SaveTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveTXTActionPerformed
          int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(null, "Выберите строку для сохранения");
        return;
    }

    JFileChooser fc = new JFileChooser();

    if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {

        try (FileWriter w = new FileWriter(fc.getSelectedFile())) {

            RecIntegral r = arrInteg.get(row);

            w.write(r.getLowerLimit() + ";" +
                    r.getUpperLimit() + ";" +
                    r.getRange() + ";" +
                    r.getResult() + "\n");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка TXT");
        }
    }
    }//GEN-LAST:event_SaveTXTActionPerformed

    private void LoadTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoadTXTActionPerformed
          JFileChooser fc = new JFileChooser();

    if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {

        try (BufferedReader br = new BufferedReader(
                new FileReader(fc.getSelectedFile()))) {

            String line = br.readLine();
            String[] p = line.split(";");

            RecIntegral r = new RecIntegral(
                    Double.parseDouble(p[0]),
                    Double.parseDouble(p[1]),
                    Double.parseDouble(p[2])
            );

            r.setResult(Double.parseDouble(p[3]));

            arrInteg.add(r);

            DefaultTableModel m = (DefaultTableModel) jTable1.getModel();

            m.addRow(new Object[]{
                    r.getLowerLimit(),
                    r.getUpperLimit(),
                    r.getRange(),
                    r.getResult()
            });

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка TXT загрузки");
        }
    }
    }//GEN-LAST:event_LoadTXTActionPerformed

    private void SaveBINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBINActionPerformed
           int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(null, "Выберите строку для сохранения");
        return;
    }

    JFileChooser fc = new JFileChooser();

    if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {

        try (ObjectOutputStream out =
                new ObjectOutputStream(
                        new FileOutputStream(fc.getSelectedFile()))) {

            out.writeObject(arrInteg.get(row));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка BIN");
        }
    }
    }//GEN-LAST:event_SaveBINActionPerformed

    private void LoadBINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoadBINActionPerformed
         JFileChooser fc = new JFileChooser();

    if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {

        try (ObjectInputStream in =
                new ObjectInputStream(
                        new FileInputStream(fc.getSelectedFile()))) {

            RecIntegral r = (RecIntegral) in.readObject();

            arrInteg.add(r);

            DefaultTableModel m = (DefaultTableModel) jTable1.getModel();

            m.addRow(new Object[]{
                    r.getLowerLimit(),
                    r.getUpperLimit(),
                    r.getRange(),
                    r.getResult()
            });

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка BIN загрузки");
        }
    }

    }//GEN-LAST:event_LoadBINActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Laba1UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Laba1UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Laba1UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Laba1UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Laba1UI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Calculate;
    private javax.swing.JButton Clear;
    private javax.swing.JButton Delete;
    private javax.swing.JButton Fill;
    private javax.swing.JButton LoadBIN;
    private javax.swing.JButton LoadTXT;
    private javax.swing.JButton SaveBIN;
    private javax.swing.JButton SaveTXT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextFieldLowLim;
    private javax.swing.JTextField jTextFieldStep;
    private javax.swing.JTextField jTextFieldUpperLim;
    // End of variables declaration//GEN-END:variables
}
