package my.Laba1;

public class IntegralThread extends Thread {

    private final double lower;
    private final double upper;
    private final double step;
    private double result;

    public IntegralThread(double lower, double upper, double step) {
        this.lower = lower;
        this.upper = upper;
        this.step = step;
    }

    @Override
    public void run() {

        double start = lower;
        double sum = 0.0;

        while (start < upper) {

            double h = Math.min(step, upper - start);

            double y1 = Math.exp(-start);
            double y2 = Math.exp(-(start + h));

            sum += h * (y1 + y2) / 2.0;

            start += h;
        }

        result = sum;
    }

    public double getResult() {
        return result;
    }
}